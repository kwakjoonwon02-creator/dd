'use strict';

/**
 * Google Apps Script ↔ Invidious video bridge
 * Runtime: Node.js 18+
 * Dependencies: none (uses built-in fetch/http)
 */

const http = require('node:http');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const { URL } = require('node:url');

const HOST = process.env.HOST || '127.0.0.1';
const PORT = numberEnv('PORT', 8787, 1, 65535);
const BRIDGE_KEY = process.env.BRIDGE_KEY || '';
const INVIDIOUS_BASE = stripTrailingSlash(process.env.INVIDIOUS_BASE || 'http://127.0.0.1:3000');
const WORK_DIR = process.env.WORK_DIR || '/var/lib/gas-invidious-bridge';
const FFMPEG_BIN = process.env.FFMPEG_BIN || 'ffmpeg';
const JOB_TTL_MS = numberEnv('JOB_TTL_MINUTES', 120, 10, 1440) * 60_000;
const MAX_JOBS = numberEnv('MAX_CONCURRENT_JOBS', 2, 1, 8);
const MAX_VIDEO_SECONDS = numberEnv('MAX_VIDEO_SECONDS', 14_400, 60, 86_400);
const TRANSCODE_FALLBACK = /^(1|true|yes)$/i.test(process.env.TRANSCODE_FALLBACK || '0');
const REQUEST_TIMEOUT_MS = numberEnv('REQUEST_TIMEOUT_MS', 30_000, 3_000, 120_000);
const MAX_CHUNK = 512 * 1024;
const MAX_IMAGE_BYTES = 3 * 1024 * 1024;
const jobs = new Map();
const jobByKey = new Map();

if (!BRIDGE_KEY || BRIDGE_KEY.length < 24) {
  console.error('BRIDGE_KEY must be set and should be at least 24 characters.');
  process.exit(1);
}

fs.mkdirSync(WORK_DIR, { recursive: true, mode: 0o750 });

const server = http.createServer(async (req, res) => {
  try {
    setSecurityHeaders(res);

    if (req.url === '/healthz' && req.method === 'GET') {
      return sendJson(res, 200, {
        ok: true,
        service: 'gas-invidious-bridge',
        invidious: INVIDIOUS_BASE,
        activeJobs: activeJobCount(),
      });
    }

    if (!authorized(req)) {
      return sendJson(res, 401, { ok: false, error: 'unauthorized' });
    }

    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

    if (req.method === 'POST' && url.pathname === '/api/search') {
      const body = await readJson(req);
      const q = limitedString(body.q, 'q', 1, 200);
      const page = intValue(body.page ?? 1, 1, 1000, 'page');
      const type = allowValue(body.type || 'all', ['all', 'video', 'channel', 'playlist', 'movie', 'show'], 'type');
      const data = await invidiousJson('/api/v1/search', {
        q,
        page,
        type,
        hl: 'ko',
        region: 'KR',
      });
      return sendJson(res, 200, data);
    }

    if (req.method === 'POST' && url.pathname === '/api/trending') {
      const body = await readJson(req);
      const type = allowValue(body.type || 'default', ['default', 'music', 'gaming', 'movies'], 'type');
      const data = await invidiousJson('/api/v1/trending', { type, region: 'KR', hl: 'ko' });
      return sendJson(res, 200, data);
    }

    if (req.method === 'POST' && url.pathname === '/api/channel/info') {
      const body = await readJson(req);
      const id = channelId(body.id);
      const data = await invidiousJson(`/api/v1/channels/${encodeURIComponent(id)}`, { hl: 'ko' });
      return sendJson(res, 200, data);
    }

    if (req.method === 'POST' && url.pathname === '/api/channel/videos') {
      const body = await readJson(req);
      const id = channelId(body.id);
      const continuation = optionalString(body.continuation, 12_000);
      const sortBy = allowValue(body.sortBy || 'newest', ['newest', 'popular', 'oldest'], 'sortBy');
      const data = await invidiousJson(`/api/v1/channels/${encodeURIComponent(id)}/videos`, {
        continuation: continuation || undefined,
        sort_by: sortBy,
        hl: 'ko',
      });
      return sendJson(res, 200, data);
    }

    if (req.method === 'POST' && url.pathname === '/api/channel/search') {
      const body = await readJson(req);
      const id = channelId(body.id);
      const q = limitedString(body.q, 'q', 1, 200);
      const page = intValue(body.page ?? 1, 1, 1000, 'page');
      const data = await invidiousJson(`/api/v1/channels/${encodeURIComponent(id)}/search`, {
        q,
        page,
        hl: 'ko',
      });
      return sendJson(res, 200, data);
    }

    if (req.method === 'POST' && url.pathname === '/api/playlist') {
      const body = await readJson(req);
      const id = playlistId(body.id);
      const page = intValue(body.page ?? 1, 1, 1000, 'page');
      const data = await invidiousJson(`/api/v1/playlists/${encodeURIComponent(id)}`, { page, hl: 'ko' });
      return sendJson(res, 200, data);
    }

    if (req.method === 'POST' && url.pathname === '/api/video/info') {
      const body = await readJson(req);
      const id = videoId(body.id);
      const info = await getVideoInfo(id);
      return sendJson(res, 200, publicVideoInfo(info));
    }

    if (req.method === 'POST' && url.pathname === '/api/jobs') {
      const body = await readJson(req);
      const id = videoId(body.videoId);
      const maxHeight = allowHeight(body.maxHeight ?? 1080);
      const job = await createOrReuseJob(id, maxHeight);
      return sendJson(res, 200, publicJob(job));
    }

    const jobStatusMatch = url.pathname.match(/^\/api\/jobs\/([a-f0-9-]{36})$/);
    if (req.method === 'GET' && jobStatusMatch) {
      const job = getJob(jobStatusMatch[1]);
      await refreshJobSize(job);
      return sendJson(res, 200, publicJob(job));
    }

    const jobChunkMatch = url.pathname.match(/^\/api\/jobs\/([a-f0-9-]{36})\/chunk$/);
    if (req.method === 'GET' && jobChunkMatch) {
      const job = getJob(jobChunkMatch[1]);
      const offset = intValue(url.searchParams.get('offset') ?? 0, 0, Number.MAX_SAFE_INTEGER, 'offset');
      const length = intValue(url.searchParams.get('length') ?? 256 * 1024, 1, MAX_CHUNK, 'length');
      return sendJobChunk(res, job, offset, length);
    }

    if (req.method === 'DELETE' && jobStatusMatch) {
      const job = getJob(jobStatusMatch[1]);
      await removeJob(job);
      return sendJson(res, 200, { ok: true });
    }

    if (req.method === 'POST' && url.pathname === '/api/image') {
      const body = await readJson(req);
      const rawUrl = limitedString(body.url, 'url', 1, 4_000);
      return proxyImage(res, rawUrl);
    }

    return sendJson(res, 404, { ok: false, error: 'not_found' });
  } catch (error) {
    const status = Number.isInteger(error.statusCode) ? error.statusCode : 500;
    console.error(new Date().toISOString(), req.method, req.url, error.stack || error.message || error);
    if (!res.headersSent) {
      sendJson(res, status, {
        ok: false,
        error: status >= 500 ? 'bridge_error' : 'bad_request',
        message: safeMessage(error),
      });
    } else {
      res.destroy(error);
    }
  }
});

server.listen(PORT, HOST, () => {
  console.log(`gas-invidious-bridge listening on http://${HOST}:${PORT}`);
});

setInterval(cleanExpiredJobs, 10 * 60_000).unref();

function numberEnv(name, fallback, min, max) {
  const value = Number(process.env[name] ?? fallback);
  if (!Number.isFinite(value) || value < min || value > max) return fallback;
  return Math.floor(value);
}

function stripTrailingSlash(value) {
  return String(value).replace(/\/+$/, '');
}

function setSecurityHeaders(res) {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
}

function authorized(req) {
  const supplied = String(req.headers['x-bridge-key'] || '');
  const expected = BRIDGE_KEY;
  if (!supplied || supplied.length !== expected.length) return false;
  return crypto.timingSafeEqual(Buffer.from(supplied), Buffer.from(expected));
}

function sendJson(res, statusCode, data) {
  const body = Buffer.from(JSON.stringify(data));
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
  });
  res.end(body);
}

function httpError(statusCode, message) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

function safeMessage(error) {
  const message = String(error?.message || 'Unknown error');
  return message.replace(/https?:\/\/[^\s]+/g, '[upstream-url]').slice(0, 500);
}

async function readJson(req, maxBytes = 1024 * 1024) {
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > maxBytes) throw httpError(413, 'Request body too large');
    chunks.push(chunk);
  }
  if (!total) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw httpError(400, 'Invalid JSON body');
  }
}

function limitedString(value, name, min, max) {
  const text = String(value ?? '').trim();
  if (text.length < min || text.length > max) throw httpError(400, `${name} length is invalid`);
  return text;
}

function optionalString(value, max) {
  if (value === undefined || value === null || value === '') return '';
  const text = String(value);
  if (text.length > max) throw httpError(400, 'String is too long');
  return text;
}

function intValue(value, min, max, name) {
  const number = Number(value);
  if (!Number.isSafeInteger(number) || number < min || number > max) {
    throw httpError(400, `${name} is invalid`);
  }
  return number;
}

function allowValue(value, allowed, name) {
  const text = String(value);
  if (!allowed.includes(text)) throw httpError(400, `${name} is invalid`);
  return text;
}

function allowHeight(value) {
  const height = Number(value);
  if (![360, 720, 1080].includes(height)) throw httpError(400, 'maxHeight must be 360, 720, or 1080');
  return height;
}

function videoId(value) {
  const id = String(value || '');
  if (!/^[A-Za-z0-9_-]{6,20}$/.test(id)) throw httpError(400, 'Invalid video id');
  return id;
}

function channelId(value) {
  const id = String(value || '');
  if (!/^UC[A-Za-z0-9_-]{20,32}$/.test(id)) throw httpError(400, 'Invalid channel id');
  return id;
}

function playlistId(value) {
  const id = String(value || '');
  if (!/^[A-Za-z0-9_-]{10,100}$/.test(id)) throw httpError(400, 'Invalid playlist id');
  return id;
}

async function invidiousJson(apiPath, params = {}) {
  const url = new URL(`${INVIDIOUS_BASE}${apiPath}`);
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, String(value));
  }

  const response = await fetchWithTimeout(url, {
    headers: {
      Accept: 'application/json',
      'User-Agent': 'gas-invidious-bridge/1.0',
    },
  });
  const text = await response.text();
  if (!response.ok) {
    throw httpError(response.status >= 500 ? 502 : response.status, `Invidious returned ${response.status}: ${text.slice(0, 300)}`);
  }
  try {
    return JSON.parse(text);
  } catch {
    throw httpError(502, 'Invidious returned invalid JSON');
  }
}

async function fetchWithTimeout(url, options = {}, timeout = REQUEST_TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (error) {
    if (error.name === 'AbortError') throw httpError(504, 'Upstream request timed out');
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function getVideoInfo(id) {
  const info = await invidiousJson(`/api/v1/videos/${encodeURIComponent(id)}`, { hl: 'ko' });
  if (info.error) throw httpError(502, String(info.error));
  return info;
}

function publicVideoInfo(info) {
  return {
    videoId: info.videoId,
    title: info.title,
    author: info.author,
    authorId: info.authorId,
    lengthSeconds: info.lengthSeconds,
    liveNow: Boolean(info.liveNow),
    description: info.description,
    videoThumbnails: info.videoThumbnails || [],
    availableHeights: availableHeights(info),
  };
}

function availableHeights(info) {
  const values = new Set();
  for (const format of [...(info.adaptiveFormats || []), ...(info.formatStreams || [])]) {
    const height = formatHeight(format);
    if (height) values.add(height);
  }
  return [...values].sort((a, b) => a - b);
}

function formatHeight(format) {
  const candidates = [format.qualityLabel, format.resolution, format.quality, format.size];
  for (const value of candidates) {
    const match = String(value || '').match(/(?:^|x)(\d{3,4})(?:p|$)/i) || String(value || '').match(/(\d{3,4})p/i);
    if (match) return Number(match[1]);
  }
  return 0;
}

function parseCodecs(type) {
  const match = String(type || '').match(/codecs="([^"]+)"/i);
  if (!match) return [];
  return match[1].split(',').map((item) => item.trim()).filter(Boolean);
}

function videoCodec(format) {
  return parseCodecs(format.type).find((codec) => /^(avc1|av01|vp09|vp9|hvc1|hev1)/i.test(codec)) || '';
}

function audioCodec(format) {
  return parseCodecs(format.type).find((codec) => /^(mp4a|opus|vorbis)/i.test(codec)) || '';
}

function isH264(codec) {
  return /^(avc1|h264)/i.test(codec || '');
}

function isAac(codec) {
  return /^mp4a/i.test(codec || '');
}

function bitrate(format) {
  return Number(format.bitrate || 0) || 0;
}

function normalizeMediaUrl(value) {
  if (!value) throw httpError(502, 'Invidious format URL is missing');
  return new URL(String(value), `${INVIDIOUS_BASE}/`).toString();
}

function chooseFormats(info, maxHeight) {
  const adaptive = Array.isArray(info.adaptiveFormats) ? info.adaptiveFormats : [];
  const progressive = Array.isArray(info.formatStreams) ? info.formatStreams : [];

  const h264Videos = adaptive
    .filter((f) => f.url && /video\/mp4/i.test(f.type || '') && formatHeight(f) > 0 && formatHeight(f) <= maxHeight && isH264(videoCodec(f)))
    .sort((a, b) => formatHeight(b) - formatHeight(a) || bitrate(b) - bitrate(a));

  const anyMp4Videos = adaptive
    .filter((f) => f.url && /video\/mp4/i.test(f.type || '') && formatHeight(f) > 0 && formatHeight(f) <= maxHeight)
    .sort((a, b) => formatHeight(b) - formatHeight(a) || bitrate(b) - bitrate(a));

  const aacAudios = adaptive
    .filter((f) => f.url && /audio\/mp4/i.test(f.type || '') && isAac(audioCodec(f)))
    .sort((a, b) => bitrate(b) - bitrate(a));

  const anyMp4Audios = adaptive
    .filter((f) => f.url && /audio\/mp4/i.test(f.type || ''))
    .sort((a, b) => bitrate(b) - bitrate(a));

  const video = h264Videos[0] || anyMp4Videos[0];
  const audio = aacAudios[0] || anyMp4Audios[0];

  if (video && audio) {
    const vCodec = videoCodec(video);
    const aCodec = audioCodec(audio);
    const needsVideoTranscode = !isH264(vCodec);
    const needsAudioTranscode = !isAac(aCodec);
    if ((needsVideoTranscode || needsAudioTranscode) && !TRANSCODE_FALLBACK) {
      throw httpError(422, 'Safari-compatible H.264/AAC stream was not available. Enable TRANSCODE_FALLBACK=1 to convert it.');
    }
    return {
      mode: 'adaptive',
      video,
      audio,
      height: formatHeight(video),
      videoCodec: needsVideoTranscode ? 'avc1.640028' : vCodec,
      audioCodec: needsAudioTranscode ? 'mp4a.40.2' : aCodec,
      transcodeVideo: needsVideoTranscode,
      transcodeAudio: needsAudioTranscode,
    };
  }

  const combined = progressive
    .filter((f) => f.url && /video\/mp4/i.test(f.type || '') && formatHeight(f) > 0 && formatHeight(f) <= maxHeight)
    .sort((a, b) => formatHeight(b) - formatHeight(a) || bitrate(b) - bitrate(a))[0];

  if (!combined) throw httpError(422, 'No compatible MP4 format was returned by Invidious');
  const codecs = parseCodecs(combined.type);
  const vCodec = codecs.find((codec) => /^(avc1|av01|vp09|vp9|hvc1|hev1)/i.test(codec)) || '';
  const aCodec = codecs.find((codec) => /^(mp4a|opus|vorbis)/i.test(codec)) || '';
  const needsVideoTranscode = !isH264(vCodec);
  const needsAudioTranscode = !isAac(aCodec);
  if ((needsVideoTranscode || needsAudioTranscode) && !TRANSCODE_FALLBACK) {
    throw httpError(422, 'No Safari-compatible combined MP4 format was available');
  }
  return {
    mode: 'progressive',
    combined,
    height: formatHeight(combined),
    videoCodec: needsVideoTranscode ? 'avc1.640028' : (vCodec || 'avc1.4d401f'),
    audioCodec: needsAudioTranscode ? 'mp4a.40.2' : (aCodec || 'mp4a.40.2'),
    transcodeVideo: needsVideoTranscode,
    transcodeAudio: needsAudioTranscode,
  };
}

async function createOrReuseJob(id, maxHeight) {
  const key = `${id}:${maxHeight}`;
  const existingId = jobByKey.get(key);
  if (existingId) {
    const existing = jobs.get(existingId);
    if (existing && Date.now() - existing.createdAt < JOB_TTL_MS && existing.status !== 'error') {
      await refreshJobSize(existing);
      return existing;
    }
    jobByKey.delete(key);
  }

  if (activeJobCount() >= MAX_JOBS) throw httpError(429, 'Too many active conversion jobs');

  const info = await getVideoInfo(id);
  if (info.liveNow || info.isUpcoming) throw httpError(422, 'Live and upcoming streams are not supported by this bridge');
  const lengthSeconds = Number(info.lengthSeconds || 0);
  if (lengthSeconds > MAX_VIDEO_SECONDS) throw httpError(422, `Video exceeds MAX_VIDEO_SECONDS (${MAX_VIDEO_SECONDS})`);

  const selected = chooseFormats(info, maxHeight);
  const jobId = crypto.randomUUID();
  const filePath = path.join(WORK_DIR, `${jobId}.mp4`);
  const mime = `video/mp4; codecs="${selected.videoCodec}, ${selected.audioCodec}"`;
  const job = {
    id: jobId,
    key,
    videoId: id,
    title: info.title || id,
    author: info.author || '',
    authorId: info.authorId || '',
    height: selected.height,
    mime,
    filePath,
    status: 'starting',
    size: 0,
    done: false,
    error: '',
    stderr: '',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    process: null,
  };

  jobs.set(jobId, job);
  jobByKey.set(key, jobId);
  startFfmpeg(job, selected);
  return job;
}

function activeJobCount() {
  let count = 0;
  for (const job of jobs.values()) {
    if (job.status === 'starting' || job.status === 'running') count += 1;
  }
  return count;
}

function startFfmpeg(job, selected) {
  const args = ['-hide_banner', '-loglevel', 'warning', '-y'];
  const inputOptions = ['-rw_timeout', '15000000', '-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_delay_max', '5'];

  if (selected.mode === 'adaptive') {
    args.push(...inputOptions, '-i', normalizeMediaUrl(selected.video.url));
    args.push(...inputOptions, '-i', normalizeMediaUrl(selected.audio.url));
    args.push('-map', '0:v:0', '-map', '1:a:0');
  } else {
    args.push(...inputOptions, '-i', normalizeMediaUrl(selected.combined.url));
    args.push('-map', '0:v:0', '-map', '0:a:0?');
  }

  if (selected.transcodeVideo) {
    args.push('-c:v', 'libx264', '-preset', 'veryfast', '-crf', '22', '-profile:v', 'high', '-level:v', '4.0', '-pix_fmt', 'yuv420p');
  } else {
    args.push('-c:v', 'copy');
  }

  if (selected.transcodeAudio) {
    args.push('-c:a', 'aac', '-b:a', '160k', '-ac', '2');
  } else {
    args.push('-c:a', 'copy');
  }

  args.push(
    '-movflags', 'frag_keyframe+empty_moov+default_base_moof',
    '-frag_duration', '2000000',
    '-flush_packets', '1',
    '-f', 'mp4',
    job.filePath,
  );

  const child = spawn(FFMPEG_BIN, args, {
    stdio: ['ignore', 'ignore', 'pipe'],
    windowsHide: true,
  });
  job.process = child;
  job.status = 'running';
  job.updatedAt = Date.now();

  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (chunk) => {
    job.stderr = (job.stderr + chunk).slice(-16_000);
    job.updatedAt = Date.now();
  });

  child.on('error', (error) => {
    job.status = 'error';
    job.error = error.message;
    job.done = true;
    job.updatedAt = Date.now();
  });

  child.on('close', async (code, signal) => {
    await refreshJobSize(job);
    job.process = null;
    job.done = true;
    job.updatedAt = Date.now();
    if (code === 0 && job.size > 0) {
      job.status = 'done';
    } else {
      job.status = 'error';
      job.error = `ffmpeg exited with code=${code} signal=${signal || ''}: ${job.stderr.slice(-1200)}`;
    }
  });
}

function getJob(id) {
  const job = jobs.get(id);
  if (!job) throw httpError(404, 'Job not found or expired');
  return job;
}

async function refreshJobSize(job) {
  try {
    const stat = await fsp.stat(job.filePath);
    job.size = stat.size;
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    job.size = 0;
  }
  job.updatedAt = Date.now();
}

function publicJob(job) {
  return {
    id: job.id,
    videoId: job.videoId,
    title: job.title,
    author: job.author,
    authorId: job.authorId,
    height: job.height,
    mime: job.mime,
    status: job.status,
    size: job.size,
    done: job.done,
    error: job.error ? safeMessage(new Error(job.error)) : '',
    createdAt: job.createdAt,
  };
}

async function sendJobChunk(res, job, offset, length) {
  await refreshJobSize(job);
  if (offset >= job.size) {
    res.writeHead(204, {
      'X-Job-Size': String(job.size),
      'X-Job-Done': job.done ? '1' : '0',
    });
    return res.end();
  }

  const endExclusive = Math.min(job.size, offset + length);
  const actualLength = endExclusive - offset;
  const handle = await fsp.open(job.filePath, 'r');
  try {
    const buffer = Buffer.allocUnsafe(actualLength);
    const { bytesRead } = await handle.read(buffer, 0, actualLength, offset);
    const body = buffer.subarray(0, bytesRead);
    res.writeHead(200, {
      'Content-Type': 'application/octet-stream',
      'Content-Length': body.length,
      'X-Chunk-Offset': String(offset),
      'X-Job-Size': String(job.size),
      'X-Job-Done': job.done ? '1' : '0',
    });
    res.end(body);
  } finally {
    await handle.close();
  }
}

async function removeJob(job) {
  if (job.process && !job.process.killed) job.process.kill('SIGTERM');
  jobs.delete(job.id);
  if (jobByKey.get(job.key) === job.id) jobByKey.delete(job.key);
  try {
    await fsp.unlink(job.filePath);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
}

async function cleanExpiredJobs() {
  const now = Date.now();
  for (const job of [...jobs.values()]) {
    if (now - job.updatedAt > JOB_TTL_MS && job.status !== 'running' && job.status !== 'starting') {
      try {
        await removeJob(job);
      } catch (error) {
        console.error('Failed to clean job', job.id, error.message);
      }
    }
  }
}

function resolveImageUrl(rawUrl) {
  const value = String(rawUrl || '').trim();
  if (value.startsWith('//')) return new URL(`https:${value}`);
  return new URL(value, `${INVIDIOUS_BASE}/`);
}

function allowedImageHost(hostname) {
  const host = hostname.toLowerCase();
  const invidiousHost = new URL(INVIDIOUS_BASE).hostname.toLowerCase();
  return host === invidiousHost
    || host === 'i.ytimg.com'
    || host.endsWith('.ytimg.com')
    || host === 'yt3.ggpht.com'
    || host.endsWith('.ggpht.com')
    || host.endsWith('.googleusercontent.com');
}

async function safeImageFetch(rawUrl, redirectsLeft = 3) {
  const url = resolveImageUrl(rawUrl);
  if (!['http:', 'https:'].includes(url.protocol) || !allowedImageHost(url.hostname)) {
    throw httpError(400, 'Image host is not allowed');
  }
  const response = await fetchWithTimeout(url, {
    redirect: 'manual',
    headers: {
      Accept: 'image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8',
      'User-Agent': 'gas-invidious-bridge/1.0',
    },
  });
  if ([301, 302, 303, 307, 308].includes(response.status)) {
    if (redirectsLeft <= 0) throw httpError(502, 'Too many image redirects');
    const location = response.headers.get('location');
    if (!location) throw httpError(502, 'Image redirect has no location');
    return safeImageFetch(new URL(location, url).toString(), redirectsLeft - 1);
  }
  return response;
}

async function proxyImage(res, rawUrl) {
  const response = await safeImageFetch(rawUrl);
  if (!response.ok) throw httpError(response.status >= 500 ? 502 : response.status, `Image server returned ${response.status}`);
  const contentType = String(response.headers.get('content-type') || '');
  if (!contentType.toLowerCase().startsWith('image/')) throw httpError(415, 'Upstream response is not an image');
  const declaredLength = Number(response.headers.get('content-length') || 0);
  if (declaredLength > MAX_IMAGE_BYTES) throw httpError(413, 'Image is too large');
  const data = Buffer.from(await response.arrayBuffer());
  if (data.length > MAX_IMAGE_BYTES) throw httpError(413, 'Image is too large');
  res.writeHead(200, {
    'Content-Type': contentType,
    'Content-Length': data.length,
    'Cache-Control': 'private, max-age=3600',
  });
  res.end(data);
}

function shutdown(signal) {
  console.log(`Received ${signal}; shutting down`);
  for (const job of jobs.values()) {
    if (job.process && !job.process.killed) job.process.kill('SIGTERM');
  }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 10_000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
