#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "root로 실행하세요: sudo bash install.sh"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

apt-get update
apt-get install -y ffmpeg nodejs

NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]")"
if (( NODE_MAJOR < 18 )); then
  echo "Node.js 18 이상이 필요합니다. 현재: $(node -v)"
  exit 1
fi

id -u gasbridge >/dev/null 2>&1 || useradd --system --home /nonexistent --shell /usr/sbin/nologin gasbridge
install -d -o root -g root -m 0755 /opt/gas-invidious-bridge
install -d -o gasbridge -g gasbridge -m 0750 /var/lib/gas-invidious-bridge
install -o root -g root -m 0644 "$SCRIPT_DIR/server.js" /opt/gas-invidious-bridge/server.js
install -o root -g root -m 0644 "$SCRIPT_DIR/gas-invidious-bridge.service" /etc/systemd/system/gas-invidious-bridge.service

if [[ ! -f /etc/gas-invidious-bridge.env ]]; then
  install -o root -g gasbridge -m 0640 "$SCRIPT_DIR/.env.example" /etc/gas-invidious-bridge.env
  echo
  echo "반드시 /etc/gas-invidious-bridge.env의 BRIDGE_KEY를 변경하세요."
fi

systemctl daemon-reload
systemctl enable gas-invidious-bridge.service

echo
cat <<'MSG'
설치 완료.
1) nano /etc/gas-invidious-bridge.env
2) BRIDGE_KEY와 INVIDIOUS_BASE 확인
3) systemctl restart gas-invidious-bridge
4) systemctl status gas-invidious-bridge --no-pager
5) curl http://127.0.0.1:8787/healthz
MSG
