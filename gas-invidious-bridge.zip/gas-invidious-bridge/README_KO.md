# Google Apps Script 전용 Invidious 영상 브리지

## 구조

```text
차단된 브라우저
   │ google.script.run만 사용
   ▼
Google Apps Script 웹앱
   │ UrlFetchApp (Google 서버 IP)
   ▼
VPS Bridge (Node.js + FFmpeg)
   │
   ├─ Invidious API: 검색, 채널, 재생목록, 영상 포맷
   ├─ 썸네일 프록시
   └─ FFmpeg fragmented MP4 생성
```

브라우저 HTML에는 외부 CDN, 외부 이미지 URL, VPS URL이 직접 들어가지 않습니다. 영상은 VPS에서 조각난 MP4로 만든 뒤 GAS RPC를 통해 512 KiB씩 Base64로 전달합니다.

## 포함 파일

```text
gas/
  Code.gs
  Index.html
  appsscript.json
vps/
  server.js
  install.sh
  .env.example
  gas-invidious-bridge.service
nginx/
  gas-bridge.conf
```

## 1. VPS 설치

압축을 VPS에 풀고 다음을 실행합니다.

```bash
cd gas-invidious-bridge/vps
sudo bash install.sh
```

비밀키를 만듭니다.

```bash
openssl rand -hex 32
```

환경설정을 수정합니다.

```bash
sudo nano /etc/gas-invidious-bridge.env
```

최소 설정 예시:

```ini
BRIDGE_KEY=방금_생성한_긴_비밀키
INVIDIOUS_BASE=http://127.0.0.1:3000
HOST=127.0.0.1
PORT=8787
WORK_DIR=/var/lib/gas-invidious-bridge
FFMPEG_BIN=/usr/bin/ffmpeg
MAX_CONCURRENT_JOBS=2
JOB_TTL_MINUTES=120
MAX_VIDEO_SECONDS=14400
TRANSCODE_FALLBACK=0
```

서비스를 시작합니다.

```bash
sudo systemctl restart gas-invidious-bridge
sudo systemctl status gas-invidious-bridge --no-pager
curl http://127.0.0.1:8787/healthz
```

정상이면 다음과 비슷하게 나옵니다.

```json
{"ok":true,"service":"gas-invidious-bridge","activeJobs":0}
```

## 2. 외부 주소 연결

### 권장: HTTPS 도메인 + Nginx

`nginx/gas-bridge.conf`에서 다음을 실제 값으로 변경합니다.

- `bridge.example.com`
- TLS 인증서 경로

그 뒤 Nginx 설정을 적용합니다.

```bash
sudo cp nginx/gas-bridge.conf /etc/nginx/sites-available/gas-bridge.conf
sudo ln -s /etc/nginx/sites-available/gas-bridge.conf /etc/nginx/sites-enabled/gas-bridge.conf
sudo nginx -t
sudo systemctl reload nginx
```

VPS 방화벽에서는 이 주소를 Google Apps Script의 UrlFetch 발신 IP에서만 접근 가능하도록 제한합니다. IP 제한 외에도 `BRIDGE_KEY` 검증이 항상 적용됩니다.

### 임시 테스트: VPS IP와 포트 직접 사용

HTTPS 도메인이 아직 없으면 환경설정에서 다음처럼 바꿀 수 있습니다.

```ini
HOST=0.0.0.0
PORT=8787
```

GAS에는 `http://VPS_IP:8787`을 입력합니다. 인터넷 구간에 평문 비밀키가 지나가므로 장기 사용에는 권장하지 않습니다.

## 3. Google Apps Script 등록

1. 새 Apps Script 프로젝트를 만듭니다.
2. `Code.gs` 내용을 `gas/Code.gs`로 교체합니다.
3. HTML 파일을 새로 만들고 이름을 `Index`로 지정한 뒤 `gas/Index.html`을 붙여넣습니다.
4. 프로젝트 설정에서 매니페스트 파일 표시를 켜고 `appsscript.json`을 `gas/appsscript.json` 내용으로 교체합니다.
5. `Code.gs`의 `configureBridge()` 안에 VPS 주소와 같은 비밀키를 입력합니다.

```javascript
const VPS_BASE_URL = 'https://bridge.example.com';
const BRIDGE_KEY = 'VPS와_동일한_비밀키';
```

6. Apps Script 편집기에서 `configureBridge`를 1회 실행하고 권한을 승인합니다.
7. `healthCheck`를 실행해 VPS 연결을 확인합니다.
8. 웹 앱으로 새 배포합니다. 실행 사용자는 본인으로 설정하고, 접근 권한은 사용 환경에 맞게 제한합니다.

코드를 바꾼 뒤에는 기존 배포 URL에 자동 반영되지 않을 수 있으므로 새 버전으로 배포를 갱신합니다.

## 4. 제공 기능

- Invidious 전체 검색
- 영상, 채널, 재생목록 필터 검색
- 채널 페이지 열기
- 채널 영상 더 보기
- 채널 내부 검색
- 재생목록 열기
- 인기 영상
- 썸네일 GAS 우회 전송
- 360p, 720p, 1080p 선택
- H.264 영상 + AAC 음성을 FFmpeg로 합쳐 fragmented MP4 스트리밍
- MediaSource 미지원 기기는 전체 다운로드 후 재생으로 자동 전환

## 5. 현재 제한

- 라이브 방송과 예약 방송은 지원하지 않습니다.
- 일반 설정은 iPad 호환성을 위해 H.264/AAC를 우선하므로 최대 1080p입니다.
- 영상 앞부분부터 순차 전송하므로 아직 버퍼링되지 않은 먼 구간으로 즉시 탐색할 수 없습니다.
- MediaSource 미지원 기기의 전체 다운로드 재생은 600MB로 제한했습니다.
- 512 KiB마다 GAS 호출 1회가 필요합니다. 예를 들어 500MB 영상은 약 1,000회의 UrlFetch 호출이 발생합니다.
- Apps Script는 대용량 영상 CDN이 아니므로 소수 사용자용으로 적합합니다. 다중 사용자 서비스는 Cloud Run이나 정식 HTTPS 리버스 프록시가 더 적합합니다.

## 6. 문제 해결

### `먼저 configureBridge()를 수정하고 1회 실행하세요`

`configureBridge()` 값을 수정한 뒤 편집기에서 직접 실행하지 않은 상태입니다.

### `unauthorized`

VPS의 `/etc/gas-invidious-bridge.env`와 GAS의 `BRIDGE_KEY`가 다릅니다.

### `No compatible MP4 format`

Invidious가 해당 영상의 MP4 포맷을 받지 못했습니다. Invidious 로그와 `/api/v1/videos/VIDEO_ID` 응답을 확인합니다.

### `Safari-compatible H.264/AAC stream was not available`

환경설정에서 다음을 켜면 FFmpeg가 호환 형식으로 변환합니다. CPU 사용량이 크게 늘어납니다.

```ini
TRANSCODE_FALLBACK=1
```

변경 후:

```bash
sudo systemctl restart gas-invidious-bridge
```

### 영상 준비가 멈춤

```bash
sudo journalctl -u gas-invidious-bridge -n 200 --no-pager
sudo -u gasbridge test -w /var/lib/gas-invidious-bridge && echo writable
ffmpeg -version
curl http://127.0.0.1:3000/api/v1/stats
```

### 웹앱은 열리는데 검색이 실패함

Apps Script 실행 기록에서 오류를 확인하고, VPS에서 다음을 확인합니다.

```bash
sudo systemctl status gas-invidious-bridge --no-pager
sudo journalctl -u gas-invidious-bridge -f
```

## 보안 주의

- `BRIDGE_KEY`를 공개 저장소에 올리지 마세요.
- 브리지 포트를 전 세계에 그대로 열지 말고 방화벽과 HTTPS를 함께 사용하세요.
- 본인이 접근 권한을 가진 콘텐츠와 네트워크에서만 사용하세요.
