/**
 * Google Apps Script side of the Invidious bridge.
 * The browser never connects directly to the VPS. All calls use google.script.run.
 */

const MAX_IMAGE_BATCH = 24;
const MAX_CHUNK_BYTES = 512 * 1024;

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Invidious GAS Player');
}

/**
 * 최초 1회: 아래 두 값을 수정한 뒤 Apps Script 편집기에서 실행하세요.
 * 설정 후 BRIDGE_KEY가 보이는 것이 싫으면 이 함수의 문자열을 지워도 됩니다.
 */
function configureBridge() {
  const VPS_BASE_URL = 'https://bridge.example.com'; // 끝의 / 제외
  const BRIDGE_KEY = 'CHANGE_THIS_TO_THE_SAME_LONG_SECRET_AS_VPS';

  if (VPS_BASE_URL.indexOf('example.com') !== -1 || BRIDGE_KEY.indexOf('CHANGE_THIS') === 0) {
    throw new Error('configureBridge()의 VPS_BASE_URL과 BRIDGE_KEY를 먼저 수정하세요.');
  }

  PropertiesService.getScriptProperties().setProperties({
    VPS_BASE_URL: VPS_BASE_URL.replace(/\/+$/, ''),
    BRIDGE_KEY: BRIDGE_KEY,
  });
}

function healthCheck() {
  return parseJsonResponse_(UrlFetchApp.fetch(config_().baseUrl + '/healthz', {
    method: 'get',
    muteHttpExceptions: true,
    followRedirects: true,
  }));
}

function searchContent(query, page, type) {
  return vpsJson_('/api/search', 'post', {
    q: String(query || '').trim(),
    page: Number(page || 1),
    type: type || 'all',
  });
}

function getTrending(type) {
  return vpsJson_('/api/trending', 'post', { type: type || 'default' });
}

function getChannelInfo(channelId) {
  return vpsJson_('/api/channel/info', 'post', { id: channelId });
}

function getChannelVideos(channelId, continuation, sortBy) {
  return vpsJson_('/api/channel/videos', 'post', {
    id: channelId,
    continuation: continuation || '',
    sortBy: sortBy || 'newest',
  });
}

function searchChannel(channelId, query, page) {
  return vpsJson_('/api/channel/search', 'post', {
    id: channelId,
    q: String(query || '').trim(),
    page: Number(page || 1),
  });
}

function getPlaylist(playlistId, page) {
  return vpsJson_('/api/playlist', 'post', {
    id: playlistId,
    page: Number(page || 1),
  });
}

function getVideoInfo(videoId) {
  return vpsJson_('/api/video/info', 'post', { id: videoId });
}

function startPlayback(videoId, maxHeight) {
  return vpsJson_('/api/jobs', 'post', {
    videoId: videoId,
    maxHeight: Number(maxHeight || 1080),
  });
}

function getPlaybackJob(jobId) {
  return vpsJson_('/api/jobs/' + encodeURIComponent(jobId), 'get');
}

function deletePlaybackJob(jobId) {
  return vpsJson_('/api/jobs/' + encodeURIComponent(jobId), 'delete');
}

/**
 * 한 번에 최대 256 KiB만 반환합니다. Base64 오버헤드와 GAS RPC 크기를 줄이기 위함입니다.
 */
function getPlaybackChunk(jobId, offset, requestedLength) {
  const length = Math.max(16 * 1024, Math.min(MAX_CHUNK_BYTES, Number(requestedLength || MAX_CHUNK_BYTES)));
  const safeOffset = Math.max(0, Math.floor(Number(offset || 0)));
  const response = vpsFetch_(
    '/api/jobs/' + encodeURIComponent(jobId) + '/chunk?offset=' + safeOffset + '&length=' + length,
    'get'
  );
  const code = response.getResponseCode();
  const headers = lowerHeaders_(response.getAllHeaders());

  if (code === 204) {
    return {
      offset: safeOffset,
      length: 0,
      base64: '',
      jobSize: Number(headers['x-job-size'] || 0),
      done: String(headers['x-job-done'] || '0') === '1',
    };
  }

  if (code < 200 || code >= 300) throwVpsError_(response);
  const bytes = response.getContent();
  return {
    offset: safeOffset,
    length: bytes.length,
    base64: Utilities.base64Encode(bytes),
    jobSize: Number(headers['x-job-size'] || 0),
    done: String(headers['x-job-done'] || '0') === '1',
  };
}

/**
 * 브라우저가 차단된 썸네일 호스트에 직접 접근하지 않도록 VPS→GAS→data URI로 전달합니다.
 */
function fetchImages(urls) {
  if (!Array.isArray(urls)) throw new Error('urls must be an array');
  const unique = [];
  const seen = Object.create(null);

  urls.forEach(function (url) {
    const text = String(url || '');
    if (!text || seen[text] || unique.length >= MAX_IMAGE_BATCH) return;
    seen[text] = true;
    unique.push(text);
  });

  if (!unique.length) return [];
  const cfg = config_();
  const requests = unique.map(function (url) {
    return {
      url: cfg.baseUrl + '/api/image',
      method: 'post',
      contentType: 'application/json',
      payload: JSON.stringify({ url: url }),
      headers: { 'X-Bridge-Key': cfg.key },
      muteHttpExceptions: true,
      followRedirects: true,
    };
  });

  const responses = UrlFetchApp.fetchAll(requests);
  return responses.map(function (response, index) {
    const code = response.getResponseCode();
    if (code < 200 || code >= 300) {
      return { url: unique[index], dataUri: '', error: 'HTTP ' + code };
    }
    const headers = lowerHeaders_(response.getAllHeaders());
    const contentType = String(headers['content-type'] || 'image/jpeg').split(';')[0];
    return {
      url: unique[index],
      dataUri: 'data:' + contentType + ';base64,' + Utilities.base64Encode(response.getContent()),
      error: '',
    };
  });
}

function config_() {
  const props = PropertiesService.getScriptProperties();
  const baseUrl = String(props.getProperty('VPS_BASE_URL') || '').replace(/\/+$/, '');
  const key = String(props.getProperty('BRIDGE_KEY') || '');
  if (!baseUrl || !/^https?:\/\//i.test(baseUrl) || !key) {
    throw new Error('먼저 configureBridge()를 수정하고 1회 실행하세요.');
  }
  return { baseUrl: baseUrl, key: key };
}

function vpsJson_(path, method, payload) {
  const response = vpsFetch_(path, method, payload);
  return parseJsonResponse_(response);
}

function vpsFetch_(path, method, payload) {
  const cfg = config_();
  const options = {
    method: String(method || 'get').toLowerCase(),
    headers: {
      'X-Bridge-Key': cfg.key,
      Accept: 'application/json',
    },
    muteHttpExceptions: true,
    followRedirects: true,
  };

  if (payload !== undefined) {
    options.contentType = 'application/json';
    options.payload = JSON.stringify(payload);
  }

  return UrlFetchApp.fetch(cfg.baseUrl + path, options);
}

function parseJsonResponse_(response) {
  const code = response.getResponseCode();
  const text = response.getContentText('UTF-8');
  let parsed;
  try {
    parsed = text ? JSON.parse(text) : {};
  } catch (error) {
    throw new Error('VPS가 JSON이 아닌 응답을 보냈습니다. HTTP ' + code + ': ' + text.slice(0, 300));
  }
  if (code < 200 || code >= 300) {
    throw new Error(parsed.message || parsed.error || ('VPS HTTP ' + code));
  }
  return parsed;
}

function throwVpsError_(response) {
  const code = response.getResponseCode();
  const text = response.getContentText('UTF-8');
  let message = '';
  try {
    const parsed = JSON.parse(text);
    message = parsed.message || parsed.error || '';
  } catch (ignored) {}
  throw new Error(message || ('VPS HTTP ' + code + ': ' + text.slice(0, 300)));
}

function lowerHeaders_(headers) {
  const out = {};
  Object.keys(headers || {}).forEach(function (key) {
    const value = headers[key];
    out[String(key).toLowerCase()] = Array.isArray(value) ? value[0] : value;
  });
  return out;
}
